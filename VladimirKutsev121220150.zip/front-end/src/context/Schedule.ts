import { writable } from 'svelte/store';

export const SelectedCity = writable(null);
export const SelectedRoute = writable(null);
export const SelectedSchedule = writable(null);

<script>
	import Router from "./navigation/router.svelte";
</script>

<main>
	<Router />
</main>
